
public class Main extends MenuUI {

    public static void main(String[] args) {

        //Kallar på en metod som visar menyn och dess val
        showMenu();

    }


}
